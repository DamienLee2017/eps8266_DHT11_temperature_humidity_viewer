# 1. 进入Python交互环境
cd /vol1/1000/workspace/temperature_humidity_viewer
source venv/bin/activate
python

# 2. 在打开的Python交互提示符 (>>>) 中，逐行输入以下命令：
import iotdb
print("iotdb模块的文件位置:", iotdb.__file__)
print("\niotdb模块的所有属性:")
for item in dir(iotdb):
    if not item.startswith('_'):  # 过滤掉内部属性
        print(f"  - {item}")

# 3. 尝试发现与'Session'相关的类
print("\n--- 尝试发现Session类 ---")
session_class = None
for item in dir(iotdb):
    if 'session' in item.lower() or 'Session' in item:
        try:
            obj = getattr(iotdb, item)
            if hasattr(obj, '__name__'):
                print(f"发现类/模块: {item} -> {obj.__name__}")
            else:
                print(f"发现属性: {item} -> {type(obj)}")
        except:
            pass

# 4. 退出交互环境 (输入 exit() 或按 Ctrl+D)
exit()
# 1. 测试连接
curl -s http://192.168.2.35:8889/api/test | python -m json.tool

# 2. 获取日期列表 (现在应返回["2025-12-11", "1970-01-01"])
curl -s http://192.168.2.35:8889/api/dates | python -m json.tool

# 3. 查询今天的数据 (根据日期列表中的实际日期)
curl -s "http://192.168.2.35:8889/api/data?date=2025-12-11" | python -m json.tool

# 4. 查询历史测试数据
curl -s "http://192.168.2.35:8889/api/data?date=1970-01-01" | python -m json.tool
#!/usr/bin/env python3
"""
测试直接使用 next() 读取IoTDB数据
"""
from iotdb.Session import Session
from datetime import datetime, timedelta
import sys

HOST = "192.168.2.35"
PORT = "6667"
USER = "root"
PASS = "root"
DEVICE = "root.sensor.dht11"

try:
    print(f"连接 {HOST}:{PORT} ...")
    session = Session(HOST, PORT, USER, PASS)
    session.open(False)
    
    sql = f"SELECT * FROM {DEVICE} LIMIT 5"
    print(f"执行: {sql}")
    result_set = session.execute_query_statement(sql)
    
    row_count = 0
    print("\n开始逐行读取结果:")
    while result_set.has_next():
        row = result_set.next()
        row_count += 1
        ts = row.get_timestamp()
        fields = row.get_fields()
        
        print(f"\n行 {row_count}:")
        print(f"  时间戳: {ts} -> {datetime.fromtimestamp(ts/1000.0)}")
        print(f"  字段数: {len(fields)}")
        
        for i, field in enumerate(fields):
            val = None
            # 尝试多种取值方式
            try:
                val = field.get_float() if hasattr(field, 'get_float') else None
            except:
                try:
                    val = field.get_float_v() if hasattr(field, 'get_float_v') else None
                except:
                    try:
                        val = float(field)
                    except:
                        val = str(field)
            print(f"  字段{i}: {type(field)} -> 值: {val}")
    
    result_set.close_operation_handle()
    session.close()
    print(f"\n✅ 成功! 共读取 {row_count} 行数据。")
    
except Exception as e:
    print(f"\n❌ 失败: {e}", file=sys.stderr)
    import traceback
    traceback.print_exc()

// 全局图表实例和配置
let tempHumChart = null;
const API_BASE = window.location.origin; // 根据实际部署调整，如 "http://192.168.2.35:8000"

// 页面加载初始化
document.addEventListener('DOMContentLoaded', async function() {
    await loadAvailableDates();
    await loadData(); // 默认加载当天数据
    // 每60秒自动刷新一次数据
    setInterval(loadData, 60000);
});

// 加载可用日期列表
async function loadAvailableDates() {
    try {
        const response = await fetch(`${API_BASE}/api/dates`);
        const data = await response.json();
        const select = document.getElementById('dateSelect');
        
        select.innerHTML = '';
        if (data.dates && data.dates.length > 0) {
            data.dates.forEach(date => {
                const option = document.createElement('option');
                option.value = date;
                option.textContent = date;
                // 默认选中今天
                const today = new Date().toISOString().split('T')[0];
                if (date === today) option.selected = true;
                select.appendChild(option);
            });
        } else {
            const today = new Date().toISOString().split('T')[0];
            select.innerHTML = `<option value="${today}">${today} (今天)</option>`;
        }
    } catch (error) {
        console.error('加载日期列表失败:', error);
        showMessage('加载日期列表失败，请检查后端服务', 'error');
    }
}

// 加载选定日期的数据
async function loadData() {
    const dateSelect = document.getElementById('dateSelect');
    const selectedDate = dateSelect.value;
    const refreshBtn = document.getElementById('refreshBtn');
    const messageDiv = document.getElementById('message');
    
    if (!selectedDate) {
        showMessage('请先选择日期', 'error');
        return;
    }
    
    // 禁用按钮，显示加载状态
    refreshBtn.disabled = true;
    refreshBtn.innerHTML = '<span>⏳ 加载中...</span>';
    messageDiv.innerHTML = '<div class="loading">📊 正在获取数据...</div>';
    
    try {
        // 获取数据
        const response = await fetch(`${API_BASE}/api/data?date=${selectedDate}&tz_offset=8`);
        const result = await response.json();
        
        if (result.error) {
            showMessage(`数据加载失败: ${result.error}`, 'error');
            return;
        }
        
        if (result.count === 0) {
            showMessage(`选定的日期 (${selectedDate}) 没有数据，请尝试其他日期`, 'info');
            updateStats([], []);
            updateChart([], [], [], selectedDate);
            return;
        }
        
        // 更新统计信息
        updateStats(result.temperature, result.humidity);
        
        // 更新图表
        updateChart(result.time, result.temperature, result.humidity, selectedDate);
        
        // 更新最后刷新时间
        document.getElementById('lastUpdate').textContent = new Date().toLocaleTimeString('zh-CN');
        
        showMessage(`成功加载 ${selectedDate} 的数据，共 ${result.count} 个数据点`, 'success');
        
    } catch (error) {
        console.error('加载数据失败:', error);
        showMessage('加载数据失败，请检查网络连接和后端服务', 'error');
    } finally {
        // 恢复按钮状态
        refreshBtn.disabled = false;
        refreshBtn.innerHTML = '<span>🔄 加载数据</span>';
    }
}

// 更新统计信息
function updateStats(temperatures, humidities) {
    if (temperatures.length === 0) {
        ['avgTemp', 'avgHum', 'maxTemp', 'dataPoints'].forEach(id => {
            document.getElementById(id).textContent = '--';
        });
        return;
    }
    
    // 计算平均值
    const avgTemp = (temperatures.reduce((a, b) => a + b, 0) / temperatures.length).toFixed(1);
    const avgHum = (humidities.reduce((a, b) => a + b, 0) / humidities.length).toFixed(1);
    
    // 计算最大值
    const maxTemp = Math.max(...temperatures).toFixed(1);
    
    document.getElementById('avgTemp').textContent = avgTemp;
    document.getElementById('avgHum').textContent = avgHum;
    document.getElementById('maxTemp').textContent = maxTemp;
    document.getElementById('dataPoints').textContent = temperatures.length;
}

// 更新图表
function updateChart(labels, tempData, humData, date) {
    const ctx = document.getElementById('tempHumChart').getContext('2d');
    
    // 如果图表已存在，销毁它
    if (tempHumChart) {
        tempHumChart.destroy();
    }
    
    // 创建新图表
    tempHumChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '温度 (°C)',
                    data: tempData,
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3,
                    yAxisID: 'y'
                },
                {
                    label: '湿度 (%)',
                    data: humData,
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                title: {
                    display: true,
                    text: `📈 ${date} 温湿度曲线`,
                    font: { size: 16 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) label += ': ';
                            label += context.parsed.y.toFixed(2);
                            label += context.dataset.label.includes('温度') ? '°C' : '%';
                            return label;
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: '时间'
                    },
                    ticks: {
                        maxRotation: 45
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: '温度 (°C)'
                    },
                    min: Math.min(...tempData) - 2,
                    max: Math.max(...tempData) + 2
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: '湿度 (%)'
                    },
                    min: Math.min(...humData) - 5,
                    max: Math.max(...humData) + 5,
                    grid: {
                        drawOnChartArea: false
                    }
                }
            }
        }
    });
}

// 跳转到今天
function goToToday() {
    const today = new Date().toISOString().split('T')[0];
    const select = document.getElementById('dateSelect');
    
    for (let option of select.options) {
        if (option.value === today) {
            option.selected = true;
            loadData();
            return;
        }
    }
    
    // 如果今天不在列表中，添加它
    const newOption = document.createElement('option');
    newOption.value = today;
    newOption.textContent = today + ' (今天)';
    newOption.selected = true;
    select.prepend(newOption);
    loadData();
}

// 显示消息
function showMessage(text, type = 'info') {
    const messageDiv = document.getElementById('message');
    const className = type === 'error' ? 'error' : 'loading';
    messageDiv.innerHTML = `<div class="${className}">${text}</div>`;
    
    // 3秒后自动清除非错误消息
    if (type !== 'error') {
        setTimeout(() => {
            if (messageDiv.innerHTML.includes(text)) {
                messageDiv.innerHTML = '';
            }
        }, 3000);
    }
}

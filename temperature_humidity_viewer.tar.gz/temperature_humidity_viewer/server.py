#!/usr/bin/env python3
"""
温湿度数据可视化后端 - 终极修复版
修复: 1) 完全使用next()逐行读取 2) 修正Field字段值提取 3) 确保能查询到所有数据
运行: python server.py
访问: http://你的NAS_IP:8889
"""
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from datetime import datetime, timedelta
import logging
import sys

# ============ 配置日志 ============
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# ============ 【配置区】 ============
IOTDB_HOST = "192.168.2.35"
IOTDB_PORT = "6667"
IOTDB_USER = "root"
IOTDB_PASS = "root"
DEVICE_PATH = "root.sensor.dht11"
SERVER_PORT = 8889
# ==================================

# ============ FastAPI应用初始化 ============
app = FastAPI(title="温湿度监控", version="2.0-ultimate")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============ IoTDB 连接函数 ============
def get_iotdb_session():
    """创建并返回一个IoTDB会话。"""
    try:
        from iotdb.Session import Session
        session = Session(IOTDB_HOST, IOTDB_PORT, IOTDB_USER, IOTDB_PASS)
        session.open(False)
        return session
    except Exception as e:
        logger.error(f"创建会话失败: {e}")
        raise

# ============ 核心：Field字段值提取函数 ============
def extract_field_value(field):
    """
    通用字段值提取函数，适配IoTDB 2.x Field对象
    经过测试验证的有效方法
    """
    if field is None:
        return None
    
    try:
        # 方法1: 直接调用get_object()方法（IoTDB 2.x推荐）
        if hasattr(field, 'get_object'):
            return field.get_object()
        
        # 方法2: 通过字符串表示提取
        field_str = str(field)
        # 寻找字符串中的数值部分
        if 'value=' in field_str:
            import re
            match = re.search(r'value=([\d\.]+)', field_str)
            if match:
                return float(match.group(1))
        
        # 方法3: 最后的备选方案
        try:
            return float(field_str)
        except:
            return None
            
    except Exception as e:
        logger.debug(f"字段提取失败: {e}, field={field}")
        return None

# ============ API 端点 ============
@app.get("/")
async def serve_frontend():
    """提供前端页面"""
    try:
        return FileResponse("static/index.html")
    except:
        return JSONResponse(content={
            "service": "温湿度监控API (终极版)",
            "status": "运行中",
            "endpoints": {
                "test": "/api/test",
                "dates": "/api/dates",
                "data": "/api/data?date=YYYY-MM-DD"
            }
        })

@app.get("/api/test")
async def test_connection():
    """测试IoTDB连接与数据读取"""
    session = None
    try:
        session = get_iotdb_session()
        logger.info("✅ IoTDB连接成功")
        
        sql = f"SELECT * FROM {DEVICE_PATH} LIMIT 3"
        result_set = session.execute_query_statement(sql)
        
        test_data = []
        row_count = 0
        
        while result_set.has_next():
            row = result_set.next()
            row_count += 1
            ts = row.get_timestamp()
            
            # 转换为可读时间
            dt = datetime.fromtimestamp(ts / 1000.0)
            time_str = dt.strftime("%Y-%m-%d %H:%M:%S")
            
            # 提取字段值
            fields = row.get_fields()
            values = []
            for i, field in enumerate(fields):
                values.append(extract_field_value(field))
            
            test_data.append({
                "time": time_str,
                "timestamp": ts,
                "values": values
            })
        
        result_set.close_operation_handle()
        session.close()
        
        return JSONResponse(status_code=200, content={
            "status": "success",
            "message": f"连接成功，读取到 {row_count} 行数据",
            "server": f"{IOTDB_HOST}:{IOTDB_PORT}",
            "sample_data": test_data
        })
        
    except Exception as e:
        logger.error(f"测试失败: {e}")
        if session:
            session.close()
        return JSONResponse(status_code=500, content={
            "status": "error",
            "message": "测试失败",
            "error": str(e)
        })

@app.get("/api/dates")
async def get_available_dates():
    """获取有数据的日期列表"""
    session = None
    try:
        session = get_iotdb_session()
        sql = f"SELECT * FROM {DEVICE_PATH}"
        result_set = session.execute_query_statement(sql)
        
        dates = set()
        row_count = 0
        
        while result_set.has_next():
            row = result_set.next()
            row_count += 1
            ts = row.get_timestamp()
            
            # 转换为日期（东八区）
            dt_utc = datetime.utcfromtimestamp(ts / 1000.0)
            dt_local = dt_utc + timedelta(hours=8)
            date_str = dt_local.strftime("%Y-%m-%d")
            dates.add(date_str)
        
        result_set.close_operation_handle()
        session.close()
        
        logger.info(f"日期处理完成: 共{row_count}行, {len(dates)}个日期")
        dates_list = sorted(list(dates), reverse=True)
        return {"dates": dates_list, "count": len(dates_list)}
        
    except Exception as e:
        logger.error(f"获取日期列表失败: {e}")
        if session:
            session.close()
        return {"dates": [], "count": 0, "error": str(e)}

@app.get("/api/data")
async def get_sensor_data(
    date: str = Query(..., description="查询日期，格式 YYYY-MM-DD")
):
    """获取指定日期的温湿度数据"""
    session = None
    try:
        # 解析日期
        query_date = datetime.strptime(date, "%Y-%m-%d")
        
        # 计算该日期的开始和结束（东八区时间）
        start_local = datetime(query_date.year, query_date.month, query_date.day, 0, 0, 0)
        end_local = start_local + timedelta(days=1) - timedelta(milliseconds=1)
        
        # 转换为UTC时间戳（毫秒）
        start_ts = int(start_local.timestamp() * 1000) - (8 * 3600 * 1000)
        end_ts = int(end_local.timestamp() * 1000) - (8 * 3600 * 1000)
        
        logger.info(f"查询 {date}, 时间戳范围: {start_ts} 至 {end_ts}")
        
        session = get_iotdb_session()
        sql = f"""
        SELECT * FROM {DEVICE_PATH}
        WHERE time >= {start_ts} AND time <= {end_ts}
        ORDER BY time ASC
        """
        
        result_set = session.execute_query_statement(sql)
        
        times, temps, hums = [], [], []
        row_count = 0
        
        while result_set.has_next():
            row = result_set.next()
            row_count += 1
            ts = row.get_timestamp()
            
            # 转换为东八区时间字符串
            dt_utc = datetime.utcfromtimestamp(ts / 1000.0)
            dt_local = dt_utc + timedelta(hours=8)
            time_str = dt_local.strftime("%H:%M:%S")
            times.append(time_str)
            
            # 提取温度湿度值
            fields = row.get_fields()
            if len(fields) >= 2:
                temp_val = extract_field_value(fields[0])
                hum_val = extract_field_value(fields[1])
                
                temps.append(round(float(temp_val), 2) if temp_val is not None else None)
                hums.append(round(float(hum_val), 2) if hum_val is not None else None)
            else:
                temps.append(None)
                hums.append(None)
        
        result_set.close_operation_handle()
        session.close()
        
        logger.info(f"数据查询完成: 获取{row_count}行")
        
        response = {
            "date": date,
            "time": times,
            "temperature": temps,
            "humidity": hums,
            "count": len(times)
        }
        
        # 统计信息
        valid_temps = [t for t in temps if t is not None]
        valid_hums = [h for h in hums if h is not None]
        if valid_temps:
            response["statistics"] = {
                "temperature_avg": round(sum(valid_temps) / len(valid_temps), 2),
                "humidity_avg": round(sum(valid_hums) / len(valid_hums), 2) if valid_hums else None
            }
        
        return response
        
    except ValueError:
        return JSONResponse(status_code=400, content={"error": "日期格式错误"})
    except Exception as e:
        logger.error(f"数据查询失败: {e}")
        if session:
            session.close()
        return JSONResponse(status_code=500, content={"error": f"查询失败: {str(e)}"})

# ============ 静态文件服务 ============
try:
    app.mount("/static", StaticFiles(directory="static"), name="static")
except Exception as e:
    logger.warning(f"静态文件目录加载失败: {e}")

# ============ 主程序入口 ============
if __name__ == "__main__":
    import uvicorn
    
    print("\n" + "="*50)
    print("温湿度监控服务 - 终极修复版 启动")
    print("="*50)
    print(f"Web界面: http://<本机IP>:{SERVER_PORT}")
    print(f"数据库: {IOTDB_HOST}:{IOTDB_PORT}")
    print(f"设备路径: {DEVICE_PATH}")
    print("="*50 + "\n")
    
    try:
        uvicorn.run(app, host="0.0.0.0", port=SERVER_PORT, log_level="info", reload=False)
    except KeyboardInterrupt:
        logger.info("服务停止")
    except Exception as e:
        logger.critical(f"启动失败: {e}")
        sys.exit(1)